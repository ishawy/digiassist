<?php
error_reporting(0);
session_start();
include('connection.php');
if (isset($_POST['login'])) {

    // build a function to validate data
    function validateFormData($formData)
    {
        $formData = trim(stripslashes(htmlspecialchars($formData)));
        return $formData;
    }
    // create varibles
    //wrap data with  our function
    // $formEmail = validateFormData($_POST['email']);
    // $formPass = validateFormData($_POST['password']);


    $email= $password=''; 

    if(!$_POST["email"]){
      $emailError = 'Please type in Your Email <br>';
    }else{
      $formEmail = validateFormData($_POST['email']);
    }

    if(!$_POST["password"]){
      $passwordError = 'Please type in Password <br>';
    }else{
      $formPass = validateFormData($_POST['password']);
    }
    include('connection.php');
    // create a SQL query
    $query = "SELECT * FROM users WHERE email='$formEmail'";

    // storing the resulta
    $result = mysqli_query($conn, $query);

    // verify if the results is returned
    if (mysqli_num_rows($result) > 0) {
        // store basic user data in variables
        while($row = mysqli_fetch_assoc($result)) {
            $name = $row['name'];
            $email = $row['email'];
            $hashedPass = $row['password'];
            $accessLevel = $row['accessLevel'];
        }
        //verify hashedpassword with typed password
        if (password_verify($formPass, $hashedPass)) {
            // correct login details
            // start the session 
            session_start();
            //store data in session variables
            $_SESSION['loggedInName'] = $name;
            $_SESSION['loggedInEmail'] = $email;
            $_SESSION['accessLevel'] = $accessLevel;

            if ($accessLevel == 'admin') {
                header("Location: dashboard.php");

            } else if ($accessLevel == 'entry') {
                header("Location: register.php");
            }
        } else {
            //Hashed password did not much
            // error message
            $loginError = "<div class='alert alert-danger'>Wrong Username / Password combination. Try Again</div>";
        }
    } else {
        // there no results in database
        $loginError = "<div class='alert alert-danger'>No Such user in database.</div>";
        // echo "Error".$query."<br>".mysqli_errno($conn);
    }
}
     mysqli_close($conn);

?>

<head>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!--<link href="style.css" rel="stylesheet">-->
        <link rel="stylesheet" type="text/css" href="style.css">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

<body>
<style>
        .container {
        background: url("img/fg.jpg") top left no-repeat;
        background-size: cover;
        display: table;
        width: 100%;
        height: 100%;
        padding: 0 10%;
    
        }
    </style>
<div class="container">
            <div class="row">
                <div class="col-md-4">
                </div>
            
                <div class="col-md-4" >

                      <h4 align="center"><b><i>System Login</i></b></h4>

                            <h5><i> <?php echo $loginError ?></i></h5>

                            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="row g-3">

                            <div class="form-group">
                            <small class="text-danger"><?php echo $emailError; ?></small>
                            <input type="email" name="email" class="form-control"  placeholder="Email" >
                            </div>

                            <div class="form-group">
                            <small class="text-danger"><?php echo $passwordError; ?></small>
                            <input type="password" name="password" class="form-control" placeholder="Password">
                            </div>
                            
                            <div class="form-group">
                            <button  type="submit" class="btn btn-primary btn-md" name="login"  align="right">Login</button>
                            </div>

                            </form>
                </div>
                
                        <div class="col-md-4">
                        </div>
             </div>
</div>    
<script>
  if(window.history.replaceState){
    window.history.replaceState(null,null,window.location.href);
  }
</script>
        <!-- Bootstrap core JavaScript
    	================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/Scripts/jquery-1.11.0.min.js"></script>
        <script src="bootstrap/Scripts/bootstrap.min.js"></script>
</body>
</html>