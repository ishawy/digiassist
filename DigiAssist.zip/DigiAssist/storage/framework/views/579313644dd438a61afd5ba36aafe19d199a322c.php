
   
<?php $__env->startSection('content'); ?>
<div class="container">
        <h3>View Program</h3>
    <?php if(count($programs) > 1): ?>
        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <h6><a href='/programs/$program->p_id'><?php echo e($program->title); ?></a></h6>
                
                <small>Program Created on <?php echo e($program->created_at); ?></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?> 
            <p>No Program Found</p>
        <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ishaw\taskMan-app\resources\views/programs/index.blade.php ENDPATH**/ ?>