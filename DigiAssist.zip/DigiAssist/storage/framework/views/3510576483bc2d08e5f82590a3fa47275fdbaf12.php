
   
<?php $__env->startSection('content'); ?>

        <h2>View Requests</h2>
    <?php if(count($reqts) > 0): ?>
        <?php $__currentLoopData = $reqts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reqt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body bg-light ">
                <h6><a href="/requests/<?php echo e($reqt->id); ?>"><?php echo e($reqt->program); ?></a></h6>
                <h6><b>Request ID:</b><?php echo e($reqt->id); ?></h6>
                <h6><b>Program:</b><?php echo e($reqt->program); ?></h6>
                <h6><b>Status:</b><?php echo e($reqt->solution); ?></h6>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
           
            
        <?php else: ?> 
            <p class="well">No Request Found</p>
        <?php endif; ?>
        <?php echo e($reqts->links()); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/requests/index.blade.php ENDPATH**/ ?>