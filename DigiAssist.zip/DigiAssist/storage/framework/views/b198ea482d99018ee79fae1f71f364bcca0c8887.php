
   
<?php $__env->startSection('content'); ?>
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>New Request</title>
        </head>
        <body>
            <div class="row">
                <div class="col-md-12">
                    <a href="/requests" class="btn btn-default">Back to Requests</a>
           
                    <?php echo Form::open(['action' => 'ReqtsController@store','method'=>'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('program','Program')); ?>

                        <?php echo e(Form::text('program','',['class'=>'form-control','placeholder'=>'Program'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('category','Category')); ?>

                        <?php echo e(Form::text('category','',['class'=>'form-control','placeholder'=>'Category'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('subject','Subject')); ?>

                        <?php echo e(Form::text('subject','',['class'=>'form-control','placeholder'=>'Subject'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('desc','Description')); ?>

                        <?php echo e(Form::textarea('desc','',['class'=>'form-control','placeholder'=>'Description'])); ?>

                    </div>
                    <br>
                    
                    <br>
                    <div class="form-group">
                        <?php echo e(Form::label('urgency','Urgency(Click to Select)')); ?>

                        <?php echo e(Form::select('urgency', ['Urgent' => 'Urgent','Very High' => 'Very High','High' => 'High','Low' => 'Low'], 'S',['class'=>'form-control'])); ?> 
                    </div>
                    <br>
                    <div class="form-group">
                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                    </div>
                    <?php echo Form::close(); ?>

                 </div>
            </div>
    </div>
        </body>
        </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/requests/create.blade.php ENDPATH**/ ?>