
   
<?php $__env->startSection('content'); ?>
<a href="/requests" class="btn btn-primary">Go Back</a>
<h4 align="center"><b><?php echo e($reqt->user_name); ?></b></h4>
  <h4 align="center">REQUEST ID:<?php echo e($reqt->id); ?></h4>
  <hr>
        <h5><b>Program:</b><?php echo e($reqt->program); ?></h5>
        <h5><b>Category:</b><?php echo e($reqt->subject); ?></h5>
        <h5><b>Subject:</b><?php echo e($reqt->subject); ?></h5>
  <hr>
        <div class="well">
            <h5><?php echo e($reqt->desc); ?></h5>
        </div>
  <hr>
  <h5><b><Label>Status:</Label><?php echo e($reqt->urgency); ?></b></h5>
  <h5><b><Label>Note:</Label></b><?php echo e($reqt->note); ?></h5>
  <h5><b><Label>Solution:</Label></b><?php echo e($reqt->solution); ?></h5>
  <hr>
        <small><b><label for="">Request was Logged at:</label><?php echo e($reqt->created_at); ?></b></small>
        <br>
        <small><b><label for="">Request was closed at:</label><?php echo e($reqt->updated_at); ?></b></small>
    
  <hr>  
<a href="/requests/<?php echo e($reqt->id); ?>/edit" class="btn btn-primary">Edit</a>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/requests/show.blade.php ENDPATH**/ ?>