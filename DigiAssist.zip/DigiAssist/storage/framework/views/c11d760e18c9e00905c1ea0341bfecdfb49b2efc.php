
   
<?php $__env->startSection('content'); ?>
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Create Posts</title>
        </head>
        <body>
            
            <div class="row">
                
                 <div class="col-md-12">
                    <h3>Create Program</h3>
                    <?php echo Form::open(['action' => 'PostsController@store','method'=>'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('title','Title')); ?>

                        <?php echo e(Form::text('title','',['class'=>'form-control','placeholder'=>' Post Title'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('body','Post content')); ?>

                        <?php echo e(Form::textarea('body','',['class'=>'form-control','placeholder'=>'Post Content'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('author','author')); ?>

                        <?php echo e(Form::text('author','',['class'=>'form-control','placeholder'=>'Author'])); ?>

                    </div>
                    <br>
                    <div class="form-group">
                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                    </div>
                    <?php echo Form::close(); ?>

                 </div>
            
            </div>
        </body>
        </html>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/posts/create.blade.php ENDPATH**/ ?>