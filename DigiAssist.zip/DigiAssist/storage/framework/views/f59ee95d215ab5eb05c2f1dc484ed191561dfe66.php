
   
<?php $__env->startSection('content'); ?>


<hr>
<div class="well">
        <h1><b><?php echo e($post->title); ?></b></h1>
       
         <h6><?php echo e($post->body); ?></h6>
         <h4>Author::<?php echo e($post->author); ?></h4>
        <small><b>Created on: <?php echo e($post->created_at); ?></b></small>
        <br>
        <small><b>Updated on: <?php echo e($post->updated_at); ?></b></small>
</div>
<br>
<?php if(!@auth::guest()): ?>
<a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a>
<?php echo Form::open(['url'=>['posts',$post->id],'method'=>'POST','class' => 'pull-right']); ?>

<?php echo Form::hidden('_method','DELETE'); ?>

<hr>
<?php echo Form::submit('DELETE',['class'=>'btn btn-danger']); ?>

<?php echo Form::close(); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/posts/show.blade.php ENDPATH**/ ?>