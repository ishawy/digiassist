
   
<?php $__env->startSection('content'); ?>
<a href="/programs" class="btn btn-primary">Go Back</a>
<hr>
        <h1><?php echo e($program->title); ?></h1>

        <div class="well">
            <h6><?php echo e($program->disc); ?></h6>
        </div>
        <h6><Label>Officer Incharge:</Label><?php echo e($program->officerId); ?></h6>
        <small><label for="">This program was created:</label><?php echo e($program->created_at); ?></small>
  <hr>  
<a href="/programs/<?php echo e($program->id); ?>/edit" class="btn btn-primary">Edit</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/programs/show.blade.php ENDPATH**/ ?>