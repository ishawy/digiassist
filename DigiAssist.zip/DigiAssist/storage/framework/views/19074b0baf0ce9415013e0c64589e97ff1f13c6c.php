<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                    <h1>My Posts</h1>
                <div class="card-body">
                    <?php if(count($post) > 0): ?>
    
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card card-body bg-light">
                            <h6><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h6>
                            <small><b>This content Created on <?php echo e($post->created_at); ?></b></small>
                            <small><b>Post Updated on <?php echo e($post->updated_at); ?></b></small>
                        </div>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        
                    </div>
                    <?php else: ?> 
                        <p>No Blog post Found</p>
                    <?php endif; ?>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views//Dashboard.blade.php ENDPATH**/ ?>