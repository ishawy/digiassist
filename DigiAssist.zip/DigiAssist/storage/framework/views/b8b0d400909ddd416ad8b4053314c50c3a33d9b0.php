
   
<?php $__env->startSection('content'); ?>
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Edit Program</title>
        </head>
        <body>
            <div class="row">
                <div class="col-md-12">
                    <a href="/programs" class="btn btn-default">Back to Program</a>
                 <div class="col-md-8">
                   
                    <h3>Create Program</h3>
                    <?php echo Form::open(['action' => ['ProgramsController@update',$program->id],'method'=>'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('title','Title')); ?>

                        <?php echo e(Form::text('title',$program->title,['class'=>'form-control','placeholder'=>'Title'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('disc','Discription')); ?>

                        <?php echo e(Form::text('disc',$program->disc,['class'=>'form-control','placeholder'=>'Discription'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('category','Category')); ?>

                        <?php echo e(Form::text('category',$program->category,['class'=>'form-control','placeholder'=>'Category'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('officeId','Officer')); ?>

                        <?php echo e(Form::text('officerId',$program->officerId,['class'=>'form-control','placeholder'=>'Officer'])); ?>

                    </div>
                    <br>
                    <div class="form-group">
                        <?php echo e(form::hidden('_method','PUT')); ?>

                        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

                    </div>
                    <?php echo Form::close(); ?>

                 </div>
                </div>
            </div>
        </body>
        </html>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DigiAssist\resources\views/programs/edit.blade.php ENDPATH**/ ?>