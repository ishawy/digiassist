@extends('layouts.app')
   
@section('content')
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>New Request</title>
        </head>
        <body>
            <div class="row">
                <div class="col-md-12">
                    <a href="/requests" class="btn btn-default">Back to Requests</a>
           
                    {!! Form::open(['action' => 'ReqtsController@store','method'=>'POST']) !!}
                    <div class="form-group">
                        {{ Form::label('program','Program') }}
                        {{ Form::text('program','',['class'=>'form-control','placeholder'=>'Program'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('category','Category') }}
                        {{ Form::text('category','',['class'=>'form-control','placeholder'=>'Category'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('subject','Subject') }}
                        {{ Form::text('subject','',['class'=>'form-control','placeholder'=>'Subject'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('desc','Description') }}
                        {{ Form::textarea('desc','',['class'=>'form-control','placeholder'=>'Description'])}}
                    </div>
                    <br>
                    {{-- <div class="form-group">

                            {{Form::label('upload','UPLOAD')}}
                            {{Form::file('image')}}
                    </div> --}}
                    <br>
                    <div class="form-group">
                        {{ Form::label('urgency','Urgency(Click to Select)') }}
                        {{ Form::select('urgency', ['Urgent' => 'Urgent','Very High' => 'Very High','High' => 'High','Low' => 'Low'], 'S',['class'=>'form-control']);}} 
                    </div>
                    <br>
                    <div class="form-group">
                        {{ Form::submit('Submit',['class'=>'btn btn-primary'])}}
                    </div>
                    {!! Form::close() !!}
                 </div>
            </div>
    </div>
        </body>
        </html>
@endsection()