@extends('layouts.app')
   
@section('content')
<a href="/requests" class="btn btn-primary">Go Back</a>
<h4 align="center"><b>{{$reqt->user_name}}</b></h4>
  <h4 align="center">REQUEST ID:{{$reqt->id}}</h4>
  <hr>
        <h5><b>Program:</b>{{$reqt->program}}</h5>
        <h5><b>Category:</b>{{$reqt->subject}}</h5>
        <h5><b>Subject:</b>{{$reqt->subject}}</h5>
  <hr>
        <div class="well">
            <h5>{{$reqt->desc}}</h5>
        </div>
  <hr>
  <h5><b><Label>Status:</Label>{{$reqt->urgency}}</b></h5>
  <h5><b><Label>Note:</Label></b>{{$reqt->note}}</h5>
  <h5><b><Label>Solution:</Label></b>{{$reqt->solution}}</h5>
  <hr>
        <small><b><label for="">Request was Logged at:</label>{{$reqt->created_at}}</b></small>
        <br>
        <small><b><label for="">Request was closed at:</label>{{$reqt->updated_at}}</b></small>
    
  <hr>  
<a href="/requests/{{$reqt->id}}/edit" class="btn btn-primary">Edit</a>

@endsection()


