@extends('layouts.app')
   
@section('content')

        <h2>View Requests</h2>
    @if(count($reqts) > 0)
        @foreach ($reqts as $reqt)
            <div class="card card-body bg-light ">
                <h6><a href="/requests/{{$reqt->id}}">{{$reqt->program}}</a></h6>
                <h6><b>Request ID:</b>{{$reqt->id}}</h6>
                <h6><b>Program:</b>{{$reqt->program}}</h6>
                <h6><b>Status:</b>{{$reqt->solution}}</h6>
            </div>
            <br>
        @endforeach
        
           
            
        @else 
            <p class="well">No Request Found</p>
        @endif
        {{ $reqts->links()}}
@endsection()


