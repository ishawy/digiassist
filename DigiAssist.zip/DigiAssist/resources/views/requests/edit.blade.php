@extends('layouts.app')
   
@section('content')
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Edit Request</title>
        </head>
        <body>
            <div class="row">
                <div class="col-md-12">
                    <a href="/requests" class="btn btn-primary">Back to Request</a>
                
                   
                    <h3>Solution to Request</h3>
                    
                    {!! Form::open(['action' => ['ReqtsController@update',$reqt->id],'method'=>'POST'])!!}
                    <div class="form-group">
                        {{ Form::label('Note','Note') }}
                        {{ Form::text('note',$reqt->note,['class'=>'form-control','placeholder'=>'Note'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('Solution','Solution') }}
                        {{ Form::textarea('solution',$reqt->solution,['class'=>'form-control','placeholder'=>'Solution'])}}
                        
                    </div>
                    <br>
                    <div class="form-group">
                        {{form::hidden('_method','PUT')}}
                        {{ Form::submit('Submit',['class'=>'btn btn-primary'])}}
                    </div>
                    {!! Form::close() !!}
                 
                </div>
            </div>
        </body>
        </html>
</div>
@endsection()