@extends('layouts.app')
   
@section('content')
<div class="container">
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Create Posts</title>
        </head>
        <body>
            
            <div class="row">
                {{-- <h6><a href="/posts" class="btn btn-primary">Back to Post</a></h6> --}}
                 <div class="col-md-12">
                    <h3>Create Program</h3>
                    {!! Form::open(['action' => 'PostsController@store','method'=>'POST']) !!}
                    <div class="form-group">
                        {{ Form::label('title','Title') }}
                        {{ Form::text('title','',['class'=>'form-control','placeholder'=>' Post Title'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('body','Post content') }}
                        {{ Form::textarea('body','',['class'=>'form-control','placeholder'=>'Post Content'])}}
                    </div>
                    <div class="form-group">
                        {{ Form::label('author','author') }}
                        {{ Form::text('author','',['class'=>'form-control','placeholder'=>'Author'])}}
                    </div>
                    <br>
                    <div class="form-group">
                        {{ Form::submit('Submit',['class'=>'btn btn-primary'])}}
                    </div>
                    {!! Form::close() !!}
                 </div>
            
            </div>
        </body>
        </html>
</div>
@endsection()

