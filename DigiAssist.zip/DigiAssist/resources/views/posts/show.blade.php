@extends('layouts.app')
   
@section('content')

{{-- <a href="/posts" class="btn btn-primary" align="center">Go Back</a> --}}
<hr>
<div class="well">
        <h1><b>{{$post->title}}</b></h1>
       
         <h6>{{$post->body}}</h6>
         <h4>Author::{{$post->author}}</h4>
        <small><b>Created on: {{$post->created_at}}</b></small>
        <br>
        <small><b>Updated on: {{$post->updated_at}}</b></small>
</div>
<br>
@if (!@auth::guest())
<a href="/posts/{{$post->id}}/edit" class="btn btn-primary">Edit</a>
{!!Form::open(['url'=>['posts',$post->id],'method'=>'POST','class' => 'pull-right'])!!}
{!!Form::hidden('_method','DELETE')!!}
<hr>
{!!Form::submit('DELETE',['class'=>'btn btn-danger'])!!}
{!!Form::close()!!}
@endif
@endsection()



