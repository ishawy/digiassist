@extends('layouts.app')
   
@section('content')
<div class="container">
        <h3><b>Blog Posts</b></h3>
    @if(count($posts) > 0)
    
        @foreach ($posts as $post)
        <div class="card card-body bg-light">
                <h6><a href="/posts/{{$post->id}}">{{$post->title}}</a></h6>
                <small><b>This content Created on {{$post->created_at}}</b></small>
                <small><b>Post Updated on {{$post->updated_at}}</b></small>
            </div>
            <br>
        @endforeach
        <div>
            
        </div>
        @else 
            <p>No Blog post Found</p>
        @endif
        {!!$posts->Links()!!}
        <br>
</div>

@endsection()
