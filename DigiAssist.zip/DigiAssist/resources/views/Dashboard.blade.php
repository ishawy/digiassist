@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
           
            <div class="card card-body bg-light">
                <div class="card-header">{{ __('Dashboard') }}</div>
                <div class="col-md-2" >
                    <a href="/posts/create" class="btn btn-primary">Create Post</a>
                </div>
                
               
              <br>
                <h3 class="card-header" align="right">My Posts</h3>
            @if(count($posts)>0)
                <table class="table table-bordered" align="center">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    @foreach ($posts as $post)
                     <tr>
                        <td>{{$post->id}}</td>
                        <td>{{$post->title}}</td>
                        <td><a href="/posts/{{$post->id}}/edit" class="btn btn-warning">Edit</a></td>
                        <td>
                        {!!Form::open(['url'=>['posts',$post->id],'method'=>'POST'])!!}
                        {!!Form::hidden('_method','DELETE')!!}
                        {!!Form::submit('DELETE',['class'=>'btn btn-danger'])!!}
                        {!!Form::close()!!}
                        </td>
                     </tr>
                    @endforeach
                    
                </table>
            @else 
                <p>No Blog post Found</p>
            @endif  
            {{-- {{ $posts->links() }} --}}
            </div>
        </div>
        
    </div>
</div>
@endsection



