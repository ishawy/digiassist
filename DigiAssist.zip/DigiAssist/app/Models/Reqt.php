<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reqt extends Model
{
    
      //table Name
      protected $table='reqts';
      //Primarykey
      public $primarykey = 'id';
      //timestamp
      public $timestamps = true;


      protected $fillable =[
            'program',
            'category',
            'subject',
            'desc',
            'urgency',
            'user_id',
            'user_name',
            'note',
            'solution',
      ];
}


