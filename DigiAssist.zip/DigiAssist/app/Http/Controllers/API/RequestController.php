<?php

namespace App\Http\Controllers\API;
use App\Models\Reqt;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use App\Http\Controllers\API\Validator;
use Illuminate\Support\Facades\Validator;



class RequestController extends Controller
{
    public function index()
    {

        $reqts = reqt::all();
        if ($reqts->count() > 0) {
            return response()->json([
                'status' => 200,
                'reqts' => $reqts
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'reqts' => 'No Records found'
            ], 404);
        }
    }

    public function show($id)
    {
        $reqts = reqt::find($id);
        if ($reqts) {
            return response()->json([
                'status' => 200,
                'reqts' => $reqts
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'reqts' => 'No Records found'
            ], 404);
        }
    }

    public function store(Request $request) 
    {
        $validator = validator::make( $request->all(),[
            'program' => 'required|string|max:191',
            'category' => 'required|string|max:191',
            'subject' => 'required|string|max:191',
            'desc' => 'required|string|max:191',
            'urgency'=>'required|string|max:191',
            'user_id' => 'required|string|max:191',
            'user_name' => 'required|string|max:191',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 442,
                'error' => $validator->messages()
            ], 442);
        } else {

            $reqts = reqt::create([
                'program' => $request->program,
                'category' => $request->category,
                'subject' => $request->subject,
                'desc' => $request->desc,
                'urgency'=>$request->urgency,
                'user_id' => $request->user_id,
                'user_name' => $request->user_name,
            ]);

            if ($reqts) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Request create'
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'No Records found'
                ], 500);
            }
        }
    }

    public function edit($id){

        $reqts = reqt::find($id);
        if ($reqts) {
            return response()->json([
                'status' => 200,
                'reqts' => $reqts
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'reqts' => 'No Records found'
            ], 404);
        }

    }

    public function update(Request $request, int $id)
    {
        $validator = validator::make( $request->all(),[
            'program' => 'required|string|max:191',
            'category' => 'required|string|max:191',
            'subject' => 'required|string|max:191',
            'desc' => 'required|string|max:191',
            'urgency'=>'required|string|max:191',
            'user_id' => 'required|string|max:191',
            'user_name' => 'required|string|max:191',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 442,
                'error' => $validator->messages()
            ], 442);
        } else {

            $reqts = Reqt::find($id);
            $reqts ->update([
                'program' => $request->program,
                'category' => $request->category,
                'subject' => $request->subject,
                'desc' => $request->desc,
                'urgency'=>$request->urgency,
                'user_id' => $request->user_id,
                'user_name' => $request->user_name,
            ]);

            if ($reqts) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Request updated Successfully'
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Request not updated'
                ], 500);
            }
        }
    }
    public function destory($id){

        $reqts = Reqt::find($id);
        if($reqts){

            $reqts->delete();

        }else{
            return response()->json([
                'status' => 404,
                'message' =>'Request Not Delete'
            ], 404);
        }
    }
}
