<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Reqt;
use Illuminate\Http\Request;


class ReqtsController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth',['except'=>['index']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$reqts = reqt::all();
        
        $reqts = reqt::orderBy('id','desc')->simplePaginate(5);
        return view('requests.index',compact('reqts',$reqts));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('requests.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [

            'program'=>'required',
            'category'=>'required',
            'subject'=>'required',
            'desc'=>'required',
            'urgency'=>'required'
        ]);
        
        // create of program

        $reqt = new reqt;
        $reqt->program = $request->input('program');
        $reqt->category = $request->input('category');
        $reqt->subject = $request->input('subject');
        $reqt->desc = $request->input('desc');
        $reqt->urgency = $request->input('urgency');
        $reqt->user_id=auth()->user()->id;
        $reqt->user_name=auth()->user()->name;
       
        $reqt->save();


        return redirect('/requests')->with('success','Request Submiited Successfully');
    }

    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reqt = reqt::find($id);
        //check for correct user
        if (auth()->user()->id !=$reqt->user_id) {
            return redirect('/requests')->with('error','Unauthorized Access');
        }
        return view('requests.show')->with('reqt',$reqt);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $reqts = reqt::find($id);
        return view('requests.edit')->with('reqt',$reqts);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [

            'note'=>'required',
            'solution'=>'required'
            
        ]);
        
        // create of program

        $reqt = reqt::find($id);
        $reqt->note = $request->input('note');
        $reqt->solution = $request->input('solution');
       
        $reqt->save();


        return redirect('/requests')->with('success','Request Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
